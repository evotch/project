<form role="form">
  
  <div class="col-sm-6">
    <div class="form-group">    
      <input type="text" class="form-control" id="carRentalPickUpCity" placeholder="Seattle, WA">
    </div>
    <div class="form-group">    
      <input type="text" class="form-control" id="carRentalDropOffCity" placeholder="Same as Pickup">
    </div> 
  </div>
  <div class="col-sm-6">
    <div class="form-group">
      <input type="date" class="form-control" id="carRentalPickUpDate" placeholder="Check In">
    </div>
    <div class="form-group">
      <input type="date" class="form-control" id="carRentalDropOffDate" placeholder="Check Out">
    </div>
    <button type="submit" class="btn btn-default btn-block">Find Cars</button>
  </div>
</form>
<div class="row">
  <div class="col-sm-12">
    <div class="checkbox">
    <button type="button" class="btn btn-link">Advanced Search </button>
    </div>
  </div>
</div>
